const express = require('express');
const router = express.Router();

const tripsController = require('../app_api/controllers/trips');

router.get('/trips', tripsController.tripsList);
router.post('/trips', tripsController.tripsCreate);

module.exports = router;
