// -----------------------------------------------------
// LOAD MODULES
// -----------------------------------------------------
require('dotenv').config();
const path = require('path');
const express = require('express');
const exphbs = require('express-handlebars');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Trip = require('./server/models/trip');

// Mongo connection
const { connectMongo } = require('./server/db/mongo');

// Customer-facing website routes
const travelRouter = require('./app_server/routes/travel');

// -----------------------------------------------------
// SIMPLE ADMIN USER + JWT SECRET (Module 7)
// -----------------------------------------------------
const JWT_SECRET = process.env.JWT_SECRET || 'ChangeThisTravlrSecret123';

// Hard-coded admin user for the assignment.
// Username: admin
// Password: admin123
const ADMIN_USER = {
  username: 'admin',
  passwordHash: bcrypt.hashSync('admin123', 10)
};

// -----------------------------------------------------
// INITIALIZE EXPRESS
// -----------------------------------------------------
const app = express();

// Parse JSON body
app.use(express.json());

// -----------------------------------------------------
// CORS FOR ANGULAR ADMIN (localhost:4200)
// -----------------------------------------------------
app.use((req, res, next) => {
 res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});

// -----------------------------------------------------
// HANDLEBARS VIEW ENGINE
// -----------------------------------------------------
const hbs = exphbs.create({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials')
});

app.engine('.hbs', hbs.engine);
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

// Serve public assets
app.use(express.static(path.join(__dirname, 'public')));

// -----------------------------------------------------
// CUSTOMER WEBSITE ROUTES
// -----------------------------------------------------
app.use('/travel', travelRouter);

// Redirect homepage → /travel
app.get('/', (req, res) => res.redirect('/travel'));

// -----------------------------------------------------
// AUTH MIDDLEWARE
// -----------------------------------------------------
function requireAuth(req, res, next) {
  const header = req.headers['authorization'];

  if (!header) {
    return res.status(401).json({ error: 'Missing Authorization header' });
  }

  const parts = header.split(' ');
  const token = parts.length === 2 && parts[0] === 'Bearer' ? parts[1] : null;

  if (!token) {
    return res.status(401).json({ error: 'Invalid Authorization format' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload; // available if needed later
    next();
  } catch (err) {
    console.error('[AUTH] Token verify error:', err.message);
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// -----------------------------------------------------
// AUTH: LOGIN ROUTE
// -----------------------------------------------------
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res
        .status(400)
        .json({ error: 'Username and password are required' });
    }

    // Check username
    if (username !== ADMIN_USER.username) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check password
    const ok = await bcrypt.compare(password, ADMIN_USER.passwordHash);
    if (!ok) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Create token
    const token = jwt.sign(
      { username: ADMIN_USER.username, role: 'admin' },
      JWT_SECRET,
      { expiresIn: '2h' }
    );

    res.status(200).json({ token });
  } catch (err) {
    console.error('[API] POST /api/login error:', err.message);
    res.status(500).json({ error: 'Login failed' });
  }
});

// -----------------------------------------------------
// API ROUTES FOR ANGULAR ADMIN (PROTECTED)
// -----------------------------------------------------

// GET ALL TRIPS
app.get('/api/trips', requireAuth, async (req, res) => {
  try {
    const trips = await Trip.find().sort({ start: 1 }).lean();
    res.json(trips);
  } catch (err) {
    console.error('[API] GET /api/trips:', err.message);
    res.status(500).json({ error: 'Failed to fetch trips' });
  }
});

// GET TRIP BY CODE
app.get('/api/trips/:code', requireAuth, async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const trip = await Trip.findOne({ code }).lean();

    if (!trip) return res.status(404).json({ error: 'Trip not found' });

    res.json(trip);
  } catch (err) {
    console.error('[API] GET /api/trips/:code:', err.message);
    res.status(500).json({ error: 'Failed to fetch trip' });
  }
});

// CREATE NEW TRIP
app.post('/api/trips', requireAuth, async (req, res) => {
  try {
    const body = req.body;

    // Map Angular fields → Mongoose fields
    const data = {
      code: body.code ? body.code.toUpperCase() : undefined,
      title: body.name,
      price: body.perPerson,
      continent: body.continent || 'Unknown',
      description: body.description,
      length: body.length,
      start: body.start,
      resort: body.resort,
      image: body.image,
      allInclusive: false
    };

    const trip = await Trip.create(data);
    res.status(201).json(trip);
  } catch (err) {
    console.error('[API] POST /api/trips error:', err.message);
    res
      .status(400)
      .json({ error: 'Failed to create trip', details: err.message });
  }
});

// UPDATE TRIP
app.put('/api/trips/:code', requireAuth, async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const body = req.body;

    const update = {
      title: body.name,
      price: body.perPerson,
      continent: body.continent || 'Unknown',
      description: body.description,
      length: body.length,
      start: body.start,
      resort: body.resort,
      image: body.image
    };

    const updated = await Trip.findOneAndUpdate({ code }, update, {
      new: true,
      runValidators: true
    }).lean();

    if (!updated) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    res.json(updated);
  } catch (err) {
    console.error('[API] PUT /api/trips/:code error:', err.message);
    res
      .status(400)
      .json({ error: 'Failed to update trip', details: err.message });
  }
});

// DELETE TRIP
app.delete('/api/trips/:code', requireAuth, async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const deleted = await Trip.findOneAndDelete({ code }).lean();

    if (!deleted) return res.status(404).json({ error: 'Trip not found' });

    res.json({ message: 'Trip deleted' });
  } catch (err) {
    console.error('[API] DELETE /api/trips/:code:', err.message);
    res.status(500).json({ error: 'Failed to delete trip' });
  }
});

// -----------------------------------------------------
// 404 PAGE (KEEP THIS LAST!!!)
// -----------------------------------------------------
app.use((req, res) => {
  res.status(404).render('error', {
    title: 'Not Found',
    message: 'Sorry, that page does not exist.'
  });
});

// -----------------------------------------------------
// START SERVER
// -----------------------------------------------------
const PORT = process.env.PORT || 3000;

connectMongo()
  .then(() => {
    console.log('[Mongo] Connected successfully');
    app.listen(PORT, () =>
      console.log(`Server running at http://localhost:${PORT}`)
    );
  })
  .catch((err) => {
    console.error('[Mongo] Connection failed:', err.message);
  });
