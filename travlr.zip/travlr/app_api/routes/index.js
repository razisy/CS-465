const express = require('express');
const router = express.Router();

// Controllers
const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');

// ===============================
// AUTHENTICATION ROUTES
// ===============================

// POST /api/login → authenticate user, return JWT token
router.post('/login', ctrlAuth.login);

// POST /api/register → create a new user
router.post('/register', ctrlAuth.register);

// ===============================
// TRIP ROUTES
// ===============================

// GET /api/trips → return all trips
router.get('/trips', ctrlTrips.tripsList);

// GET /api/trips/:code → return a specific trip by tripCode
router.get('/trips/:code', ctrlTrips.tripsFindByCode);

// POST /api/trips → add a new trip
router.post('/trips', ctrlTrips.tripsAddTrip);

// PUT /api/trips/:code → update a trip by tripCode
router.put('/trips/:code', ctrlTrips.tripsUpdateTrip);

// DELETE /api/trips/:code → delete a trip
router.delete('/trips/:code', ctrlTrips.tripsDeleteTrip);

// ===============================
// EXPORT ROUTER
// ===============================
module.exports = router;
