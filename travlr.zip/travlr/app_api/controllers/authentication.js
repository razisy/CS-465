const mongoose = require('mongoose');
const User = mongoose.model('User');

module.exports.register = function(req, res) {
  const user = new User();

  user.email = req.body.email;
  user.name = req.body.name;
  user.setPassword(req.body.password);

  user.save(err => {
    if (err) return res.status(400).json(err);
    res.status(200).json({ token: user.generateJwt() });
  });
};

module.exports.login = function(req, res) {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({ message: "All fields required" });
  }

  User.findOne({ email: req.body.email }, (err, user) => {
    if (err) return res.status(400).json(err);

    if (!user || !user.validPassword(req.body.password)) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = user.generateJwt();
    res.status(200).json({ token });
  });
};
