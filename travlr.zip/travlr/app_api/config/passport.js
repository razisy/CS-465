const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');
const User = mongoose.model('User');

passport.use(new LocalStrategy(
  { usernameField: 'email' },
  (email, password, done) => {
    User.findOne({ email }, (err, user) => {
      if (err) return done(err);

      if (!user || !user.validPassword(password)) {
        return done(null, false, { message: 'Invalid email or password' });
      }

      return done(null, user);
    });
  }
));
