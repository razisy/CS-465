const path = require('path');
const express = require('express');
const exphbs = require('express-handlebars');
const travelRouter = require('./app_server/routes/travel');

const app = express();

// Set up Handlebars
const hbs = exphbs.create({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials')
});
app.engine('.hbs', hbs.engine);
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

//  Mount the travel route here
app.use('/travel', travelRouter);

// Redirect root to /travel
app.get('/', (req, res) => res.redirect('/travel'));

// 404
app.use((req, res) => {
  res.status(404).render('error', { title: 'Not Found', message: 'Sorry, that page does not exist.' });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
