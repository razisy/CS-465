import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl = 'http://localhost:3000/api';
  private tokenKey = 'travlr-token';

  // Tracks whether the user is logged in
  private loggedIn$ = new BehaviorSubject<boolean>(false);

  constructor(private http: HttpClient) {
    // On refresh, see if there's already a token
    const token = this.getToken();
    this.loggedIn$.next(!!token);
  }

  login(username: string, password: string): Observable<boolean> {
    return this.http
      .post<{ token: string }>(`${this.baseUrl}/login`, { username, password })
      .pipe(
        map(response => {
          if (response && response.token) {
            // Save token
            localStorage.setItem(this.tokenKey, response.token);
            // Update logged-in state
            this.loggedIn$.next(true);
            return true;
          }
          this.loggedIn$.next(false);
          return false;
        })
      );
  }

  // 🔹 This is what AppComponent is calling
  isLoggedIn(): Observable<boolean> {
    return this.loggedIn$.asObservable();
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
    this.loggedIn$.next(false);
  }
}
