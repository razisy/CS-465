import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { TripListComponent } from './trips/trip-list/trip-list';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, LoginComponent, TripListComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Travlr Getaways Admin';
  loggedIn = false;

  constructor(public auth: AuthService) {
    this.auth.isLoggedIn().subscribe((isIn: boolean) => {
      this.loggedIn = isIn;
    });
  }

  handleLoggedIn(value: boolean) {
    this.loggedIn = value;
  }
}
