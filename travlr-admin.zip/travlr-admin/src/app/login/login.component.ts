import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = '';
  password = '';
  error = '';
  loading = false;            // 👈 this fixes the error

  @Output() loggedIn = new EventEmitter<boolean>();

  constructor(private auth: AuthService) {}

  onSubmit() {
    this.error = '';
    this.loading = true;

    this.auth.login(this.username, this.password).subscribe(ok => {
      this.loading = false;

      if (ok) {
        this.loggedIn.emit(true);
      } else {
        this.error = 'Invalid username or password.';
      }
    });
  }
}
