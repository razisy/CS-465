import { Component } from '@angular/core';
import { TripListComponent } from './trips/trip-list/trip-list';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TripListComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {
  title = 'travlr-admin';
}
