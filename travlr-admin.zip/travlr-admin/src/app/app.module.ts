// Not used in this project (standalone Angular).
export {};
