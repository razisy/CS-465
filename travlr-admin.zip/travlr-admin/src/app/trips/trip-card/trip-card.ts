import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Trip } from '../trip';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.html',   // <-- matches trip-card.html
  styleUrl: './trip-card.css'        // <-- matches trip-card.css
})
export class TripCardComponent {
  @Input() trip!: Trip;
  @Output() edit = new EventEmitter<Trip>();
  @Output() delete = new EventEmitter<Trip>();
}
