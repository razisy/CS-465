// server/db/mongo.js
const mongoose = require('mongoose');

const uri = process.env.MONGODB_URI;
if (!uri) {
  console.error('[Mongo] MONGODB_URI not set in .env');
  process.exit(1);
}

mongoose.set('strictQuery', true);

const connectMongo = async () => {
  try {
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 10000,
      socketTimeoutMS: 45000
    });
    console.log('[Mongo] Connected:', mongoose.connection.name);
  } catch (err) {
    console.error('[Mongo] Connection error:', err.message);
    process.exit(1);
  }

  mongoose.connection.on('error', (err) => {
    console.error('[Mongo] Runtime error:', err.message);
  });

  mongoose.connection.on('disconnected', () => {
    console.warn('[Mongo] Disconnected');
  });
};

// Load server-side model (existing MVC model)
require('../models/trip');

// Load API model (new M5 REST API model)
require('../../app_api/models/trips');

module.exports = { connectMongo };
