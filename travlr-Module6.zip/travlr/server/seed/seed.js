// server/seed/seed.js
require('dotenv').config();
const fs = require('fs');
const path = require('path');

const { connectMongo } = require('../db/mongo');
const Trip = require('../models/trip');

(async () => {
  try {
    await connectMongo();

    const filePath = path.join(__dirname, 'trips.json');
    const raw = fs.readFileSync(filePath, 'utf8');
    const trips = JSON.parse(raw);

    if (!Array.isArray(trips) || trips.length === 0) {
      console.error('[Seed] trips.json is empty or invalid');
      process.exit(1);
    }

    // Clear existing trips, then insert new ones
    await Trip.deleteMany({});
    const result = await Trip.insertMany(trips);
    console.log('[Seed] Inserted trips:', result.length);

    process.exit(0);
  } catch (err) {
    console.error('[Seed] Error:', err.message);
    process.exit(1);
  }
})();
