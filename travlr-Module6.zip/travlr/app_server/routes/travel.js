const express = require('express');
const router = express.Router();
const travelCtrl = require('../controllers/travelController');

router.get('/', travelCtrl.list);
router.get('/:id', travelCtrl.detail);

module.exports = router;
