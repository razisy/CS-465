// app_server/controllers/travelController.js

// Load trips from JSON (dynamic data source)
const trips = require('../data/trips.json');

// GET /travel - list all trips
const list = (req, res) => {
  res.render('travel-list', {
    title: 'Travlr | Explore Trips',
    trips
  });
};

// GET /travel/:id - show one trip by id
const detail = (req, res) => {
  const tripId = req.params.id;
  const trip = trips.find(t => t.id === tripId);

  if (!trip) {
    return res.status(404).render('error', {
      title: 'Trip Not Found',
      message: 'We could not find that trip.'
    });
  }

  res.render('travel-detail', {
    title: `Travlr | ${trip.title}`,
    trip
  });
};

module.exports = { list, detail };
