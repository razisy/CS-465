const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
    code: { type: String, required: true },
    name: { type: String, required: true },
    length: { type: Number, required: true },
    start: { type: Date, required: true },
    resort: String,
    perPerson: Number,
    image: String,
    description: String
});

module.exports = mongoose.model('trips', tripSchema);
