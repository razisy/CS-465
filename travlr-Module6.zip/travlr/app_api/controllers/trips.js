const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

// GET /api/trips  - return all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({});
        return res.status(200).json(trips);
    } catch (err) {
        return res.status(500).json({ message: "Database error" });
    }
};

// GET /api/trips/:code  - return one trip by code
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.code });

        if (!trip) {
            return res.status(404).json({ message: "Trip not found" });
        }

        return res.status(200).json(trip);
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode
};
