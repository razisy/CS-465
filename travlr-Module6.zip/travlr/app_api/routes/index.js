const express = require('express');
const router = express.Router();
const ctrlTrips = require('../controllers/trips');

// GET /api/trips  → all trips
router.get('/trips', ctrlTrips.tripsList);

// GET /api/trips/:code  → specific trip by code
router.get('/trips/:code', ctrlTrips.tripsFindByCode);

module.exports = router;
