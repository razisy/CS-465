// -----------------------------------------------------
// LOAD MODULES
// -----------------------------------------------------
require('dotenv').config();
const path = require('path');
const express = require('express');
const exphbs = require('express-handlebars');
const Trip = require('./server/models/trip');   

// Mongo connection
const { connectMongo } = require('./server/db/mongo');

// Customer-facing website routes
const travelRouter = require('./app_server/routes/travel');

// Initialize Express
const app = express();

// Parse JSON body
app.use(express.json());

// -----------------------------------------------------
// CORS FOR ANGULAR ADMIN (localhost:4201)
// -----------------------------------------------------
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:4201');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});

// -----------------------------------------------------
// HANDLEBARS VIEW ENGINE
// -----------------------------------------------------
const hbs = exphbs.create({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials')
});

app.engine('.hbs', hbs.engine);
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

// Serve public assets
app.use(express.static(path.join(__dirname, 'public')));

// -----------------------------------------------------
// CUSTOMER WEBSITE ROUTES
// -----------------------------------------------------
app.use('/travel', travelRouter);

// Redirect homepage → /travel
app.get('/', (req, res) => res.redirect('/travel'));

// -----------------------------------------------------
// API ROUTES FOR ANGULAR ADMIN
// -----------------------------------------------------

// GET ALL TRIPS
app.get('/api/trips', async (req, res) => {
  try {
    const trips = await Trip.find().sort({ start: 1 }).lean();
    res.json(trips);
  } catch (err) {
    console.error('[API] GET /api/trips:', err.message);
    res.status(500).json({ error: 'Failed to fetch trips' });
  }
});

// GET TRIP BY CODE
app.get('/api/trips/:code', async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const trip = await Trip.findOne({ code }).lean();

    if (!trip) return res.status(404).json({ error: 'Trip not found' });

    res.json(trip);
  } catch (err) {
    console.error('[API] GET /api/trips/:code:', err.message);
    res.status(500).json({ error: 'Failed to fetch trip' });
  }
});

// CREATE NEW TRIP

app.post('/api/trips', async (req, res) => {
  try {
    const body = req.body;

    // Map Angular fields → Mongoose fields
    const data = {
      code: body.code ? body.code.toUpperCase() : undefined,

      
      title: body.name,                        
      price: body.perPerson,                  
      continent: body.continent || 'Unknown', 

      
      description: body.description,
      length: body.length,
      start: body.start,
      resort: body.resort,
      image: body.image,
      allInclusive: false                     
    };

    const trip = await Trip.create(data);
    res.status(201).json(trip);
  } catch (err) {
    console.error('[API] POST /api/trips error:', err.message);
    res.status(400).json({ error: 'Failed to create trip', details: err.message });
  }
});

// UPDATE TRIP
app.put('/api/trips/:code', async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const body = req.body;

    const update = {
      // keep code the same, or allow changing if you want:
      title: body.name,
      price: body.perPerson,
      continent: body.continent || 'Unknown',
      description: body.description,
      length: body.length,
      start: body.start,
      resort: body.resort,
      image: body.image
    };

    const updated = await Trip.findOneAndUpdate(
      { code },
      update,
      { new: true, runValidators: true }
    ).lean();

    if (!updated) {
      return res.status(404).json({ error: 'Trip not found' });
    }

    res.json(updated);
  } catch (err) {
    console.error('[API] PUT /api/trips/:code error:', err.message);
    res.status(400).json({ error: 'Failed to update trip', details: err.message });
  }
});

// DELETE TRIP
app.delete('/api/trips/:code', async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const deleted = await Trip.findOneAndDelete({ code }).lean();

    if (!deleted) return res.status(404).json({ error: 'Trip not found' });

    res.json({ message: 'Trip deleted' });
  } catch (err) {
    console.error('[API] DELETE /api/trips/:code:', err.message);
    res.status(500).json({ error: 'Failed to delete trip' });
  }
});

// -----------------------------------------------------
// 404 PAGE (KEEP THIS LAST!!!)
// -----------------------------------------------------
app.use((req, res) => {
  res.status(404).render('error', {
    title: 'Not Found',
    message: 'Sorry, that page does not exist.'
  });
});

// -----------------------------------------------------
// START SERVER
// -----------------------------------------------------
const PORT = process.env.PORT || 3000;

connectMongo()
  .then(() => {
    console.log('[Mongo] Connected successfully');
    app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('[Mongo] Connection failed:', err.message);
  });
