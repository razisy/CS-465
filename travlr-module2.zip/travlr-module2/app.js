const path = require('path');
const express = require('express');
const exphbs = require('express-handlebars');

// ROUTES (we’ll create this file next)
const travelRouter = require('./app_server/routes/travel');

const app = express();

/* ---------------- Handlebars setup ---------------- */
const hbs = exphbs.create({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials'),
});
app.engine('.hbs', hbs.engine);
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

/* ---------------- Static assets ---------------- */
app.use(express.static(path.join(__dirname, 'public')));

/* ---------------- Routes ---------------- */
app.use('/travel', travelRouter);

/* ---------------- Home redirect ---------------- */
app.get('/', (req, res) => res.redirect('/travel'));

/* ---------------- 404 page ---------------- */
app.use((req, res) => {
  res.status(404).render('error', {
    title: 'Not Found',
    message: 'Sorry, that page does not exist.'
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Travlr app listening on http://localhost:${PORT}`);
});
