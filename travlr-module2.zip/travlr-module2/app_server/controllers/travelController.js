// app_server/controllers/travelController.js

// Temporary mock data (you can swap for DB later)
const trips = [
  {
    id: 'paris-getaway',
    title: 'Paris Getaway',
    price: 1299,
    nights: 5,
    rating: 4.7,
    img: 'https://picsum.photos/seed/paris/800/450',
    summary: 'Romance, art, and croissants.'
  },
  {
    id: 'tokyo-express',
    title: 'Tokyo Express',
    price: 1899,
    nights: 7,
    rating: 4.9,
    img: 'https://picsum.photos/seed/tokyo/800/450',
    summary: 'Neon nights and sushi delights.'
  },
  {
    id: 'cancun-sun',
    title: 'Cancún Sunbreak',
    price: 899,
    nights: 4,
    rating: 4.3,
    img: 'https://picsum.photos/seed/cancun/800/450',
    summary: 'Beach, reef, and relaxation.'
  }
];

const list = (req, res) => {
  res.render('travel-list', {
    title: 'Travlr | Explore Trips',
    trips
  });
};

const detail = (req, res) => {
  const trip = trips.find(t => t.id === req.params.id);
  if (!trip) {
    return res.status(404).render('error', {
      title: 'Trip Not Found',
      message: 'We could not find that trip.'
    });
  }
  res.render('travel-detail', {
    title: `Travlr | ${trip.title}`,
    trip
  });
};

module.exports = { list, detail };
