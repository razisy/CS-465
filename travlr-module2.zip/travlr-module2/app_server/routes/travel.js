// app_server/routes/travel.js
const express = require('express');
const router = express.Router();
const travelCtrl = require('../controllers/travelController');

// /travel
router.get('/', travelCtrl.list);

// /travel/:id
router.get('/:id', travelCtrl.detail);

module.exports = router;
