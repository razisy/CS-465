// Core modules & packages
require('dotenv').config();
const path = require('path');
const express = require('express');
const exphbs = require('express-handlebars');

// MEAN stack backend connections
const { connectMongo } = require('./server/db/mongo');
const tripsApi = require('./server/routes/api/trips');

// Customer-facing route controller
const travelRouter = require('./app_server/routes/travel');

// Initialize Express
const app = express();

// Middleware for JSON (needed for API)
app.use(express.json());


const hbs = exphbs.create({
  extname: '.hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials')
});

app.engine('.hbs', hbs.engine);
app.set('view engine', '.hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

app.use(express.static(path.join(__dirname, 'public')));


app.use('/travel', travelRouter);

// Redirect root -> /travel
app.get('/', (req, res) => res.redirect('/travel'));


app.use('/api/trips', tripsApi);


app.use((req, res) => {
  res.status(404).render('error', {
    title: 'Not Found',
    message: 'Sorry, that page does not exist.'
  });
});


const PORT = process.env.PORT || 3000;

connectMongo().then(() => {
  console.log('[Mongo] Connected successfully');
  app.listen(PORT, () =>
    console.log(`Server running at http://localhost:${PORT}`)
  );
}).catch((err) => {
  console.error('[Mongo] Connection failed:', err.message);
});
