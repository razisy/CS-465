// server/routes/api/trips.js
const express = require('express');
const Trip = require('../../models/trip');

const router = express.Router();

/**
 * GET /api/trips
 * Return all trips as JSON
 */
router.get('/', async (req, res) => {
  try {
    const trips = await Trip.find().sort({ start: 1 }).lean();
    res.json(trips);
  } catch (err) {
    console.error('[Trips] GET / error:', err.message);
    res.status(500).json({ error: 'Failed to fetch trips' });
  }
});

/**
 * GET /api/trips/:code
 * Return a single trip by code
 */
router.get('/:code', async (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const trip = await Trip.findOne({ code }).lean();
    if (!trip) {
      return res.status(404).json({ error: 'Trip not found' });
    }
    res.json(trip);
  } catch (err) {
    console.error('[Trips] GET /:code error:', err.message);
    res.status(500).json({ error: 'Failed to fetch trip' });
  }
});

module.exports = router;
