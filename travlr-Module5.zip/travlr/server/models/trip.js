// server/models/trip.js
const mongoose = require('mongoose');

const TripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: [true, 'Trip code is required'],
      unique: true,
      trim: true,
      uppercase: true,
      minlength: 3,
      maxlength: 10
    },
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, required: true, maxlength: 2000 },
    length: { type: Number, required: true, min: 1, max: 365 },
    price: { type: Number, required: true, min: 0 },
    start: { type: Date, required: true },
    resort: { type: String, required: true, trim: true, maxlength: 80 },
    continent: {
      type: String,
      enum: ['Africa', 'Asia', 'Europe', 'North America', 'South America', 'Oceania', 'Antarctica'],
      required: true
    },
    image: { type: String, trim: true },
    allInclusive: { type: Boolean, default: false }
  },
  { timestamps: true, versionKey: false }
);

module.exports = mongoose.model('Trip', TripSchema);
