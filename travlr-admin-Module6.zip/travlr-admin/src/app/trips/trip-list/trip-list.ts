import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TripDataService } from '../trip-data';
import { Trip } from '../trip';
import { TripCardComponent } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCardComponent],
  templateUrl: './trip-list.html',   // <-- matches trip-list.html
  styleUrl: './trip-list.css'        // <-- matches trip-list.css
})
export class TripListComponent implements OnInit {

  trips: Trip[] = [];
  selectedTrip: Trip = this.emptyTrip();
  isEditMode = false;
  message = '';

  constructor(private tripService: TripDataService) { }

  ngOnInit(): void {
    this.loadTrips();
  }

  private emptyTrip(): Trip {
    return {
      code: '',
      name: '',
      length: 0,
      start: '',
      resort: '',
      perPerson: 0,
      image: '',
      description: ''
    };
  }

  loadTrips(): void {
    this.tripService.getTrips().subscribe({
      next: trips => this.trips = trips,
      error: err => this.message = 'Error loading trips: ' + err.message
    });
  }

  onAddNew(): void {
    this.isEditMode = false;
    this.selectedTrip = this.emptyTrip();
  }

  onEdit(trip: Trip): void {
    this.isEditMode = true;
    this.selectedTrip = { ...trip };
  }

  onDelete(trip: Trip): void {
    if (!confirm(`Delete trip "${trip.name}"?`)) return;

    this.tripService.deleteTrip(trip.code).subscribe({
      next: () => {
        this.message = 'Trip deleted.';
        this.loadTrips();
      },
      error: err => this.message = 'Error deleting trip: ' + err.message
    });
  }

  onSubmit(): void {
    if (this.isEditMode) {
      this.tripService.updateTrip(this.selectedTrip).subscribe({
        next: () => {
          this.message = 'Trip updated.';
          this.resetForm();
        },
        error: err => this.message = 'Error updating trip: ' + err.message
      });
    } else {
      this.tripService.addTrip(this.selectedTrip).subscribe({
        next: () => {
          this.message = 'Trip added.';
          this.resetForm();
        },
        error: err => this.message = 'Error adding trip: ' + err.message
      });
    }
  }

  private resetForm(): void {
    this.selectedTrip = this.emptyTrip();
    this.isEditMode = false;
    this.loadTrips();
  }
}
