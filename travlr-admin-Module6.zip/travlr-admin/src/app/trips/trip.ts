export interface Trip {
  _id?: string;        // MongoDB ID (optional)
  code: string;
  name: string;
  length: number;      // days
  start: Date | string;
  resort: string;
  perPerson: number;
  image: string;
  description: string;
}
