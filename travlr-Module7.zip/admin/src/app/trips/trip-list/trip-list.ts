// trip list placeholder
