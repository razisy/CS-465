// trips controller placeholder
