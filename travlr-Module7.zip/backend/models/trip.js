// trip model placeholder
