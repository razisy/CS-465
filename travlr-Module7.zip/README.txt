Placeholder Module 7 archive.
Add your project files here.